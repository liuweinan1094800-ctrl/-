using System;
using System.Drawing;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

public class KeyRepeater : Form {
 [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h,int id,uint mod,uint vk);
 [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h,int id);
 [DllImport("user32.dll")] static extern uint MapVirtualKey(uint code,uint type);
 [DllImport("user32.dll")] static extern uint SendInput(uint n, INPUT[] input,int size);
 [StructLayout(LayoutKind.Sequential)] struct INPUT { public uint type; public UNION u; }
 [StructLayout(LayoutKind.Explicit)] struct UNION { [FieldOffset(0)] public KEY ki; [FieldOffset(0)] public MOUSE mi; }
 [StructLayout(LayoutKind.Sequential)] struct KEY { public ushort vk, scan; public uint flags,time; public UIntPtr extra; }
 [StructLayout(LayoutKind.Sequential)] struct MOUSE { public int x,y; public uint data,flags,time; public UIntPtr extra; }
 ComboBox keys=new ComboBox(); NumericUpDown speed=new NumericUpDown();
 Label state=new Label(), detail=new Label(); Button start=new Button();
 bool held=false; INPUT release; Stopwatch clock=new Stopwatch(); double nextDown=0,upAt=0;
 Timer timer=new Timer(); bool active=false; long count;
 class Choice { public string Name; public Keys Key; public Choice(string n,Keys k){Name=n;Key=k;} public override string ToString(){return Name;} }
 void Add(string n,Keys k){keys.Items.Add(new Choice(n,k));}
 ComboBox toggleKey=new ComboBox(), stopKey=new ComboBox();
 Button stopButton=new Button(); bool ready=false, hotkeysReady=false;
 Label LabelAt(string text,int x,int y,int width,int height,Color color,float size){
  var l=new Label{Text=text,Location=new Point(x,y),Size=new Size(width,height),ForeColor=color,Font=new Font("Microsoft YaHei UI",size)};Controls.Add(l);return l;
 }
 void PlaceCombo(ComboBox c,int x,int y,int width){
  c.Location=new Point(x,y);c.Size=new Size(width,30);c.DropDownStyle=ComboBoxStyle.DropDownList;c.FlatStyle=FlatStyle.Flat;c.DrawMode=DrawMode.OwnerDrawFixed;c.ItemHeight=25;
  c.DrawItem+=delegate(object sender,DrawItemEventArgs e){e.DrawBackground();if(e.Index>=0)TextRenderer.DrawText(e.Graphics,c.Items[e.Index].ToString(),c.Font,new Rectangle(e.Bounds.X+8,e.Bounds.Y,e.Bounds.Width-8,e.Bounds.Height),e.ForeColor,TextFormatFlags.Left|TextFormatFlags.VerticalCenter);e.DrawFocusRectangle();};Controls.Add(c);
 }
 void UpdateButtons(){start.Text=(active?"暂停":"开始")+"   "+toggleKey.Text;stopButton.Text="停止   "+stopKey.Text;}
 bool ValidKeys(){
  Choice c=keys.SelectedItem as Choice;
  return c!=null && toggleKey.SelectedIndex!=stopKey.SelectedIndex && (int)c.Key!=112+toggleKey.SelectedIndex && (int)c.Key!=112+stopKey.SelectedIndex;
 }
 void ApplyHotkeys(){
  if(!ready)return;
  UnregisterHotKey(Handle,1);UnregisterHotKey(Handle,2);hotkeysReady=false;
  UpdateButtons();
  if(!ValidKeys()){start.Enabled=false;state.Text="快捷键不能重复，也不能与连按键相同。";state.ForeColor=Color.Firebrick;return;}
  bool a=RegisterHotKey(Handle,1,0x4000,(uint)(112+toggleKey.SelectedIndex));
  bool b=RegisterHotKey(Handle,2,0x4000,(uint)(112+stopKey.SelectedIndex));
  hotkeysReady=a&&b;
  if(!hotkeysReady){UnregisterHotKey(Handle,1);UnregisterHotKey(Handle,2);}
  start.Enabled=hotkeysReady;
  state.ForeColor=hotkeysReady?Color.FromArgb(30,110,90):Color.Firebrick;
  state.Text=hotkeysReady?"●  就绪":"快捷键被占用，请换一个 F 键。";
 }
 public KeyRepeater(){
  Text="键盘连按器 · 游戏兼容版";ClientSize=new Size(420,440);FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
  AutoScaleMode=AutoScaleMode.Dpi;StartPosition=FormStartPosition.CenterScreen;Font=new Font("Microsoft YaHei UI",10);BackColor=Color.FromArgb(247,249,252);
  var title=LabelAt("键盘连按器",26,24,350,36,Color.FromArgb(26,36,52),20);title.Font=new Font(Font.FontFamily,20,FontStyle.Bold);
  LabelAt("按键发送到当前窗口，切换窗口不会停止",28,67,360,24,Color.FromArgb(112,123,140),10);
  LabelAt("连按键",28,112,170,23,Color.FromArgb(65,77,95),10);
  LabelAt("速度 · 次 / 秒",222,112,170,23,Color.FromArgb(65,77,95),10);
  PlaceCombo(keys,28,140,170);
  for(int i=65;i<=90;i++)Add(((char)i).ToString(),(Keys)i);
  for(int i=48;i<=57;i++)Add(((char)i).ToString(),(Keys)i);
  Add("空格 Space",Keys.Space);Add("回车 Enter",Keys.Enter);Add("Tab",Keys.Tab);Add("退格 Backspace",Keys.Back);
  Add("上 ↑",Keys.Up);Add("下 ↓",Keys.Down);Add("左 ←",Keys.Left);Add("右 →",Keys.Right);
  for(int i=1;i<=12;i++)Add("F"+i,(Keys)(111+i));
  keys.SelectedIndex=4;
  speed.Location=new Point(222,140);speed.Size=new Size(170,30);speed.Minimum=1;speed.Maximum=50;speed.Value=10;Controls.Add(speed);
  LabelAt("开始 / 暂停",28,193,170,23,Color.FromArgb(65,77,95),10);
  LabelAt("停止",222,193,170,23,Color.FromArgb(65,77,95),10);
  PlaceCombo(toggleKey,28,221,170);PlaceCombo(stopKey,222,221,170);
  for(int i=1;i<=11;i++){toggleKey.Items.Add("F"+i);stopKey.Items.Add("F"+i);}
  toggleKey.SelectedIndex=0;stopKey.SelectedIndex=1;
  start.Location=new Point(28,278);start.Size=new Size(170,44);start.BackColor=Color.FromArgb(46,99,225);start.ForeColor=Color.White;start.FlatStyle=FlatStyle.Flat;start.FlatAppearance.BorderSize=0;start.Cursor=Cursors.Hand;Controls.Add(start);
  stopButton.Location=new Point(222,278);stopButton.Size=new Size(170,44);stopButton.BackColor=Color.White;stopButton.ForeColor=Color.FromArgb(65,77,95);stopButton.FlatStyle=FlatStyle.Flat;stopButton.FlatAppearance.BorderColor=Color.FromArgb(219,225,235);stopButton.Cursor=Cursors.Hand;Controls.Add(stopButton);
  start.Click+=delegate{Toggle();};stopButton.Click+=delegate{Stop("●  已停止");};
  state.Location=new Point(28,342);state.Size=new Size(370,25);Controls.Add(state);
  LabelAt("立即开始 · 切换窗口继续 · 按暂停或停止结束",28,382,370,22,Color.FromArgb(112,123,140),9);
  LabelAt("速度范围 1–50 次/秒 · 实际响应以目标软件为准",28,406,370,22,Color.FromArgb(112,123,140),9);
  timer.Tick+=Tick;keys.SelectedIndexChanged+=delegate{ApplyHotkeys();};toggleKey.SelectedIndexChanged+=delegate{ApplyHotkeys();};stopKey.SelectedIndexChanged+=delegate{ApplyHotkeys();};
  Shown+=delegate{ready=true;ApplyHotkeys();};
  FormClosing+=delegate{Stop("已停止");UnregisterHotKey(Handle,1);UnregisterHotKey(Handle,2);timer.Dispose();};
  UpdateButtons();
 }
 void Toggle(){
  if(active){Stop("●  已暂停");return;}
  if(held){Stop("已松开按键，请重新开始。");return;}
  if(!hotkeysReady||!ValidKeys())return;
  active=true;count=0;clock.Restart();nextDown=0;keys.Enabled=speed.Enabled=toggleKey.Enabled=stopKey.Enabled=false;UpdateButtons();
  state.ForeColor=Color.FromArgb(46,99,225);state.Text="运行中";timer.Interval=1;timer.Start();Tick(this,EventArgs.Empty);
 }
 void Stop(string message){timer.Stop();if(held){if(SendInput(1,new INPUT[]{release},Marshal.SizeOf(typeof(INPUT)))==1)held=false;else message="松键失败，请手动按下并松开连按键。";}clock.Stop();active=false;keys.Enabled=speed.Enabled=toggleKey.Enabled=stopKey.Enabled=true;UpdateButtons();state.ForeColor=Color.FromArgb(65,77,95);state.Text=message;}
 void Tick(object sender,EventArgs e){
  if(!active)return;
  double now=clock.Elapsed.TotalMilliseconds;
  if(held){
   if(now<upAt)return;
   if(SendInput(1,new INPUT[]{release},Marshal.SizeOf(typeof(INPUT)))!=1){Stop("松键失败，请检查权限。");return;}
   held=false;return;
  }
  if(now<nextDown)return;
  Choice choice=(Choice)keys.SelectedItem;
  ushort scan=(ushort)MapVirtualKey((uint)choice.Key,0);
  if(scan==0){Stop("此按键无法转换为扫描码。");return;}
  uint extended=(choice.Key==Keys.Up||choice.Key==Keys.Down||choice.Key==Keys.Left||choice.Key==Keys.Right)?1u:0u;
  INPUT down=new INPUT{type=1,u=new UNION{ki=new KEY{scan=scan,flags=8|extended}}};
  release=new INPUT{type=1,u=new UNION{ki=new KEY{scan=scan,flags=8|extended|2}}};
  if(SendInput(1,new INPUT[]{down},Marshal.SizeOf(typeof(INPUT)))!=1){Stop("输入被阻止，请检查目标软件权限。");return;}
  held=true;
  double period=1000.0/(double)speed.Value;
  upAt=now+Math.Min(40,period/2);nextDown=now+period;
  count++;state.Text="运行中 · "+choice.Name+" · 已发送 "+count+" 次";
 }
 protected override void WndProc(ref Message m){if(m.Msg==0x312){if(m.WParam.ToInt32()==1)Toggle();else if(m.WParam.ToInt32()==2)Stop("已紧急停止");}base.WndProc(ref m);}
 [STAThread] public static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new KeyRepeater());}
}
